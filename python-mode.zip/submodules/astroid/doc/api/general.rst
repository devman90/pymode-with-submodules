General API
------------

.. automodule:: astroid

