:orphan:

Welcome to Pylama
=================

.. image:: _static/logo.png

Welcome to Pylama's documentation.

.. === description ===
.. include:: ../README.rst
    :start-after: .. _description:
    :end-before: .. _documentation:

:copyright: 2013 by Kirill Klenov.
:license: BSD, see LICENSE for more details.

.. contents::

.. include:: ../README.rst
    :start-after: .. _requirements:

