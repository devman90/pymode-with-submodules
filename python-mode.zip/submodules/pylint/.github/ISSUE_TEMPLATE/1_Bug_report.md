---
name: Bug report
about: Report a bug in pylint

---

<!--
  Hi there! Thank you for discovering and submitting an issue.

  Before you submit this, make sure that the issue doesn't already exist
  or if it is not closed.

  Is your issue fixed on the preview release?: pip install pylint astroid --pre -U

-->

### Steps to reproduce
1.
2.
3.

### Current behavior


### Expected behavior


### pylint --version output

