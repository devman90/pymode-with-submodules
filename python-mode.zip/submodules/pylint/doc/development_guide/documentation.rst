.. -*- coding: utf-8 -*-

===========================
 Building the documentation
===========================

We use **tox** for building the documentation::

  $ tox -e docs
