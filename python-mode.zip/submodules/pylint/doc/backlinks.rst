
Some projects using Pylint
--------------------------
The following projects are known to use Pylint to help develop better
Python code:

* edX (https://github.com/edx)
* qutebrowser (https://github.com/The-Compiler/qutebrowser)
* Odoo (https://github.com/OCA)
* Landscape.io (https://github.com/landscapeio/)
* Codacy (https://github.com/Codacy/)
* SaltStack (https://github.com/saltstack)
* CodeFactor (https://github.com/codefactor-io)
* many more...

