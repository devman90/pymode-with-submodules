Use `pip <http://pip-installer.org>`_ or easy_install:


.. code::

    pip install pydocstyle

Alternatively, you can use ``pydocstyle.py`` source file
directly - it is self-contained.
