License
=======

.. include:: ../LICENSE-MIT
